package acousticfield3d.utils;

/**
 *
 * @author am14010
 */
public class VarConv {
    public static int uByteToInt( byte b){
        return b & 0xFF;
    }
}

package acousticfield3d.renderer;

/**
 *
 * @author am14010
 */
public class Texture {
    int id;

    public Texture() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
}

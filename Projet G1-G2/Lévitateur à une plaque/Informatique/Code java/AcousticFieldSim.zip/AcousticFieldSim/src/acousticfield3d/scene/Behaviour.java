package acousticfield3d.scene;

/**
 *
 * @author Asier
 */
public class Behaviour {
    
    public boolean tick (float dt, Entity e){
        return false;
    }
}

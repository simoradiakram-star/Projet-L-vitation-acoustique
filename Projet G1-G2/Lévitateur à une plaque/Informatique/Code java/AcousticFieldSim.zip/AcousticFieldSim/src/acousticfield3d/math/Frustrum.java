/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acousticfield3d.math;

import acousticfield3d.scene.Camera;

/**
 *
 * @author am14010
 */
public class Frustrum {

    public Frustrum(Camera camera, float minX, float minY, float maxX, float maxY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    //six planes: front, back, left, right, up, down
    
    //create from 8 points
    
    //create from camera
    
    //create from camera and crop rectangle
    
    //is Vector inside
    
    //is sphere inside
    
    //is bounding box inside
}

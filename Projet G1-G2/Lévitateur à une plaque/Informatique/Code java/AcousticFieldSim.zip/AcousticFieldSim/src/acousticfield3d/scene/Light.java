package acousticfield3d.scene;

/**
 *
 * @author Asier
 */
public class Light extends Entity{

    public Light() {
    }
    
    
}
